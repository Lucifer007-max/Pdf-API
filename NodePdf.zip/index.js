// // const express = require('express');
// // const multer = require('multer');
// // const { PDFDocument } = require('pdf-lib');
// // const fs = require('fs');

// // const app = express();
// // const upload = multer({ dest: 'uploads/' });

// // app.post('/merge', upload.array('pdfFiles'), async (req, res) => {
// //   try {
// //     const mergedPdf = await mergePDFs(req.files);
// //     const outputPath = 'uploads/merged.pdf';

// //     await fs.promises.writeFile(outputPath, await mergedPdf.save());
    
    
// //   } catch (error) {
// //     console.error('Failed to merge PDFs:', error);
// //     res.status(500).send('Failed to merge PDFs');
// //   }
// // });

// // async function mergePDFs(pdfFiles) {
// //   const mergedPdf = await PDFDocument.create();

// //   for (const file of pdfFiles) {
// //     const pdfBytes = await fs.promises.readFile(file.path);
// //     const pdfDoc = await PDFDocument.load(pdfBytes);

// //     const pages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
// //     pages.forEach((page) => mergedPdf.addPage(page));
// //   }

// //   return mergedPdf;
// // }

// // const port = 3000;
// // app.listen(port, () => {
// //   console.log(`Server is running on port ${port}`);
// // });




// const express = require('express');
// const multer = require('multer');
// const { PDFDocument } = require('pdf-lib');
// const fs = require('fs');

// const app = express();
// const upload = multer({ dest: 'uploads/' });

// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));

// app.post('/compress', upload.single('pdfFile'), async (req, res) => {
//   try {
//     const pdfPath = req.file.path;
//     const compressedPdfPath = 'compressed.pdf';

//     await compressPDF(pdfPath, compressedPdfPath);

//     res.download(compressedPdfPath, 'compressed.pdf', (err) => {
//       if (err) {
//         console.error('Failed to download compressed PDF:', err);
//         res.status(500).send('Failed to download compressed PDF');
//       } else {
//         console.log('PDF compressed and downloaded successfully!');
//       }
//     });
//   } catch (error) {
//     console.error('Failed to compress PDF:', error);
//     res.status(500).send('Failed to compress PDF');
//   }
// });

// async function compressPDF(inputPath, outputPath) {
//   const pdfBuffer = await fs.promises.readFile(inputPath);
//   const pdfDoc = await PDFDocument.load(pdfBuffer);

//   pdfDoc.getPages().forEach((page) => {
//     const contentStream = page.getContentStream();
//     const resources = contentStream.dict.get(PDFName.of('Resources')) || PDFDict.withContext(pdfDoc.context);
//     const xObjects = resources.get(PDFName.of('XObject')) || PDFDict.withContext(pdfDoc.context);

//     xObjects.forEach((name, xObjectRef) => {
//       const xObject = xObjectRef.object;
//       if (xObject instanceof PDFDict && xObject.get(PDFName.of('Subtype')) === PDFName.of('Image')) {
//         xObject.compress();
//       }
//     });
//   });

//   const compressedPdfBytes = await pdfDoc.save();
//   await fs.promises.writeFile(outputPath, compressedPdfBytes);
// }

// const port = 3000;
// app.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// });


const express = require('express');
const axios = require('axios');
const querystring = require('querystring');
const Strava = require('strava-v3');
const app = express();

const clientId = 'YOUR_STRAVA_CLIENT_ID';
const clientSecret = 'YOUR_STRAVA_CLIENT_SECRET';
const redirectUri = 'http://localhost'; // Update with your redirect URI

app.get('/auth/strava', (req, res) => {
  const params = querystring.stringify({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'read_all',
  });

  res.redirect(`https://www.strava.com/oauth/authorize?${params}`);
});

app.get('/auth/callback', async (req, res) => {
  const { code } = req.query;

  try {
    const tokenResponse = await axios.post('https://www.strava.com/oauth/token', {
      client_id: clientId,
      client_secret: clientSecret,
      code: code,
      grant_type: 'authorization_code',
    });

    const accessToken = tokenResponse.data.access_token;
    const activitiesResponse = await axios.get('https://www.strava.com/api/v3/athlete/activities', {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    const activities = activitiesResponse.data;
    // Do something with the activities

    res.json(activities);

  } catch (error) {
    console.error('OAuth error:', error);
    res.status(500).send('OAuth failed');
  }
});



const athleteId = 120145075;
const accessToken = '07a0dfeb68ad3ed70997fe00fc7f066412f6bf6a';
// const accessToken = '9bd2915e837e0301bb7b4f5095668c175cec934b';

// const accessToken = 'YOUR ACCESS TOKEN'; // Replace with your actual access token

app.get('/activities', (req, res) => {
  Strava.config({
    access_token: accessToken
  });

  Strava.athlete.listActivities({page : 1 , per_page: 10}, (err, activities) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Error retrieving activities');
    } else {
      res.json(activities);
    }
  });
});










app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
